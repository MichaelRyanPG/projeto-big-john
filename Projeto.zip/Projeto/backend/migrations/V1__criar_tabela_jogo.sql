create table jogo (
 	id int PRIMARY KEY AUTO_INCREMENT,
    titulo varchar(300) not null,
    data_lancamento date,
    genero varchar(30),
    plataforma_principal varchar(50)
);