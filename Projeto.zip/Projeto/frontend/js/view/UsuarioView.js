/**
 * Renderiza o formulário para criar uma nova tarefa.
 * @return {string} HTML do formulário de criação de tarefa.
 */
function renderizarFormulario() {
    return `
            <form class="row g-3" id="formulario_usuario">
                <div class="col-md-6">
                    <label for="usuario_titulo" class="form-label" style="color: black; font-weight: bolder;">Nome do usuário:</label>
                    <input type="text" class="form-control" id="usuario_nome_formulario"></input>
                </div>
                <div class="col-md-6">
                    <label for="usuario_nascimento" class="form-label" style="color: black; font-weight: bolder;">Data de nascimento:</label>
                    <input type="text" class="form-control" id="usuario_nascimento_formulario"></input>
                </div>
                <div class="col-md-6">
                    <label for="usuario_genero" class="form-label" style="color: black; font-weight: bolder;">Gênero:</label>
                    <input type="text" class="form-control" id="usuario_genero_formulario"></input>
                </div>
                <div class="col-md-6">
                    <label for="usuario_email" class="form-label" style="color: black; font-weight: bolder;">Email:</label>
                    <input type="text" class="form-control" id="usuario_email_formulario"></input>
                </div>
                <div class="col-md-6">
                    <label for="usuario_senha" class="form-label" style="color: black; font-weight: bolder;">Senha:</label>
                    <input type="text" class="form-control" id="usuario_senha_formulario"></input>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary mt-2">Salvar</button>
                </div>
            </form>
        `;
  }
  
  /**
   * Renderiza o formulário para atualizar uma tarefa existente.
   * @param {Object} usuario - A tarefa a ser atualizada.
   * @return {string} HTML do formulário de atualização de tarefa.
   */
  function renderizarFormularioAtualizar(usuario) {
      return `
              <form class="row g-3" id="formulario_usuario_atualizar">
                  <input type="hidden" class="form-control" id="usuario_id_formulario" value="${usuario.id}">
                  <div class="col-md-6">
                      <label for="usuario_nome" style="color: black; font-weight: bolder;" class="form-label">Nome do usuário:</label>
                      <input type="text" class="form-control" id="usuario_nome_formulario" value="${usuario.nome}">
                  </div>
                  <div class="col-md-6">
                      <label for="usuario_nascimento" style="color: black; font-weight: bolder;" class="form-label">Data de nascimento:</label>
                      <textarea class="form-control" id="usuario_nascimento_formulario">${usuario.data_nascimento}</textarea>
                  </div>
                  <div class="col-md-6">
                      <label for="usuario_genero" style="color: black; font-weight: bolder;" class="form-label">Gênero:</label>
                      <textarea class="form-control" id="usuario_genero_formulario">${usuario.genero}</textarea>
                  </div>
                  <div class="col-md-6">
                      <label for="usuario_email" style="color: black; font-weight: bolder;" class="form-label">Email:</label>
                      <textarea class="form-control" id="usuario_email_formulario">${usuario.email}</textarea>
                  </div>
                  <div class="col-md-6">
                      <label for="usuario_senha" style="color: black; font-weight: bolder;" class="form-label">Senha:</label>
                      <textarea class="form-control" id="usuario_senha_formulario">${usuario.senha}</textarea>
                  </div>
                  <div class="col-12">
                    <button type="submit" class="btn btn-primary mt-2">Salvar</button>
                  </div>
              </form>
          `;
  }
  
    /**
   * Renderiza a tabela de tarefas.
   * @param {Array} usuarios - Lista de tarefas a serem exibidas.
   * @return {string} HTML da tabela de tarefas.
   */
  function renderizarTabela(usuarios) {
    let tabela = `
            <table class="table table-striped table-dark mt-3">
                <thead>
                    <tr>
                        <th>Nome do usuário</th>
                        <th>Data de nascimento</th>
                        <th>Gênero</th>
                        <th>Email</th>
                        <th>Senha</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
        `;
  
    usuarios.forEach((usuario) => {
      tabela += `
                <tr>
                    <td>${usuario.nome}</td>
                    <td>${usuario.data_nascimento}</td>
                    <td>${usuario.genero}</td>
                    <td>${usuario.email}</td>
                    <td>${usuario.senha}</td>
                    <td>
                      <button class="excluir-btn btn btn-danger" usuario-id=${usuario.id}>Excluir</button>
                      <button class="atualizar-btn btn btn-primary" usuario-atualizar-id=${usuario.id}>Atualizar</button>
                    </td>
                </tr>
            `;
    });
  
    tabela += `
                </tbody>
            </table>
        `;
  
    return tabela;
  }
  
  const UsuarioView = {
      renderizarFormulario,
      renderizarTabela,
      renderizarFormularioAtualizar
  };
  
  export default UsuarioView;
  