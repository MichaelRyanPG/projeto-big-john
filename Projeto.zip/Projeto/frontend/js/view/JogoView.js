/**
 * Renderiza o formulário para criar uma nova tarefa.
 * @return {string} HTML do formulário de criação de tarefa.
 */
function renderizarFormulario() {
  return `
          <form class="row g-3" id="formulario_jogo">
              <div class="col-md-6">
                  <label for="jogo_titulo" class="form-label" style="color: black; font-weight: bolder;">Título do jogo:</label>
                  <input type="text" class="form-control" id="jogo_titulo_formulario"></input>
              </div>
              <div class="col-md-6">
                  <label for="jogo_lancamento" style="color: black; font-weight: bolder;" class="form-label">Data de lançamento:</label>
                  <input type="text" class="form-control" id="jogo_lancamento_formulario"></input>
              </div>
              <div class="col-md-6">
                  <label for="jogo_genero" style="color: black; font-weight: bolder;" class="form-label">Gênero:</label>
                  <input type="text" class="form-control" id="jogo_genero_formulario"></input>
              </div>
              <div class="col-md-6">
                  <label for="jogo_plataforma" style="color: black; font-weight: bolder;" class="form-label">Plataforma principal:</label>
                  <input type="text" class="form-control" id="jogo_plataforma_formulario"></input>
              </div>
              <div class="col-12">
                <button type="submit" class="btn btn-primary mt-2">Salvar</button>
              </div>
          </form>
      `;
}

/**
 * Renderiza o formulário para atualizar uma tarefa existente.
 * @param {Object} jogo - A tarefa a ser atualizada.
 * @return {string} HTML do formulário de atualização de tarefa.
 */
function renderizarFormularioAtualizar(jogo) {
    return `
            <form class="row g-3" id="formulario_jogo_atualizar">
                <input type="hidden" class="form-control" id="jogo_id_formulario" value="${jogo.id}">
                <div class="col-md-6">
                    <label for="jogo_titulo" class="form-label" style="color: black; font-weight: bolder;">Título do jogo:</label>
                    <input type="text" class="form-control" id="jogo_titulo_formulario" value="${jogo.titulo}">
                </div>
                <div class="col-md-6">
                    <label for="jogo_lancamento" class="form-label" style="color: black; font-weight: bolder;">Lançamento:</label>
                    <textarea class="form-control" id="jogo_lancamento_formulario">${jogo.data_lancamento}</textarea>
                </div>
                <div class="col-md-6">
                    <label for="jogo_genero" class="form-label" style="color: black; font-weight: bolder;">Gênero:</label>
                    <textarea class="form-control" id="jogo_genero_formulario">${jogo.genero}</textarea>
                </div>
                <div class="col-md-6">
                    <label for="jogo_plataforma" class="form-label" style="color: black; font-weight: bolder;">Plataforma principal:</label>
                    <textarea class="form-control" id="jogo_plataforma_formulario">${jogo.plataforma_principal}</textarea>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary mt-2">Salvar</button>
                </div>
            </form>
        `;
}

  /**
 * Renderiza a tabela de tarefas.
 * @param {Array} jogos - Lista de tarefas a serem exibidas.
 * @return {string} HTML da tabela de tarefas.
 */
function renderizarTabela(jogos) {
  let tabela = `
          <table class="table table-striped table-dark mt-3">
              <thead>
                  <tr>
                      <th scope="col">Título do jogo</th>
                      <th scope="col">Data de lançamento</th>
                      <th scope="col">Gênero</th>
                      <th scope="col">Plataforma principal</th>
                      <th scope="col">Ações</th>
                  </tr>
              </thead>
              <tbody>
      `;

  jogos.forEach((jogo) => {
    tabela += `
              <tr>
                  <td scope="row">${jogo.titulo}</td>
                  <td scope="row">${jogo.data_lancamento}</td>
                  <td scope="row">${jogo.genero}</td>
                  <td scope="row">${jogo.plataforma_principal}</td>
                  <td>
                    <button class="excluir-btn btn btn-danger" jogo-id=${jogo.id}>Excluir</button>
                    <button class="atualizar-btn btn btn-primary" jogo-atualizar-id=${jogo.id}>Atualizar</button>
                  </td>
              </tr>
          `;
  });

  tabela += `
              </tbody>
          </table>
      `;

  return tabela;
}

const JogoView = {
    renderizarFormulario,
    renderizarTabela,
    renderizarFormularioAtualizar
};

export default JogoView;
