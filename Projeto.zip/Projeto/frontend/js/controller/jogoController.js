import JogoView from "../view/JogoView.js";
import { API_BASE_URL } from "../config/config.js";

/**
 * Renderiza o formulário de tarefa.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde o formulário será renderizado.
 */
function renderizarJogoFormulario(componentePrincipal) {
  componentePrincipal.innerHTML = JogoView.renderizarFormulario();
  document.getElementById("formulario_jogo").addEventListener("submit", cadastrarJogo);
}

/**
 * Cadastra uma nova tarefa.
 * @param {Event} event - Evento do formulário.
 */
async function cadastrarJogo(event) {
  event.preventDefault();
  const tituloValor = document.getElementById("jogo_titulo_formulario").value;
  const lancamentoValor = document.getElementById("jogo_lancamento_formulario").value;
  const generoValor = document.getElementById("jogo_genero_formulario").value;
  const plataformaValor = document.getElementById("jogo_plataforma_formulario").value;
  const novoJogo = { titulo: tituloValor, data_lancamento: lancamentoValor, genero: generoValor,
    plataforma_principal: plataformaValor };

  try {
    await fetch(`${API_BASE_URL}/jogos`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novoJogo),
    });
    const componentePrincipal = document.querySelector("#conteudo_principal");
    await renderizarListaJogos(componentePrincipal);
  } catch (error) {
    console.error("Erro ao adicionar jogo:", error);
  }
}
/**
 * Renderiza a lista de tarefas.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde a lista será renderizada.
 */
async function renderizarListaJogos(componentePrincipal) {
  try {
    const response = await fetch(API_BASE_URL + "/jogos");
    const jogosBD = await response.json(); 

    const jogos = jogosBD.map((row) => {
      return {
        id: row.id,
        titulo: row.titulo,
        data_lancamento: row.data_lancamento,
        genero: row.genero,
        plataforma_principal: row.plataforma_principal,
      };
    });
    componentePrincipal.innerHTML = JogoView.renderizarTabela(jogos);
    inserirEventosExcluir();
    inserirEventosAtualizar();
  } catch (error) {
    console.error("Erro ao buscar jogos:", error);
  }
}

/**
 * Adiciona eventos de clique aos botões de exclusão de tarefa.
 * Cada botão, quando clicado, aciona a função de exclusão de tarefa correspondente.
 */
function inserirEventosExcluir() {
  const botoesExcluir = document.querySelectorAll(".excluir-btn");
  botoesExcluir.forEach((botao) => {
    botao.addEventListener("click", function () {
      const jogoId = this.getAttribute("jogo-id");
      excluirJogo(jogoId);
    });
  });
}

/**
 * Adiciona eventos de clique aos botões de atualização de tarefa.
 * Cada botão, quando clicado, aciona a função de buscar a tarefa específica para atualização.
 */
function inserirEventosAtualizar() {
  const botoesAtualizar = document.querySelectorAll(".atualizar-btn");
  botoesAtualizar.forEach((botao) => {
    botao.addEventListener("click", function () {
      const jogoId = this.getAttribute("jogo-atualizar-id");
      buscarJogo(jogoId);
    });
  });
}

/**
 * Exclui uma tarefa específica com base no ID.
 * Após a exclusão bem-sucedida, a lista de tarefas é atualizada.
 * @param {string} id - ID da tarefa a ser excluída.
 */
async function excluirJogo(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/jogos/${id}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Erro ao excluir o jogo");
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaJogos(componentePrincipal);
  } catch (error) {
    console.error("Erro ao excluir o jogo:", error);
  }
}

/**
 * Busca uma tarefa específica para atualização, com base no ID.
 * Após encontrar a tarefa, renderiza o formulário de atualização.
 * @param {string} id - ID da tarefa a ser buscada.
 */
async function buscarJogo(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/jogos/${id}`);
    const jogosBD = await response.json();
    if (jogosBD.length <= 0) return;

    const jogo = jogosBD.map(row => ({
        id: row.id,
        titulo: row.titulo,
        data_lancamento: row.data_lancamento,
        genero: row.genero,
        plataforma_principal: row.plataforma_principal,
    }))[0];

    const componentePrincipal = document.querySelector("#conteudo_principal");
    componentePrincipal.innerHTML = JogoView.renderizarFormularioAtualizar(jogo);
    document.getElementById("formulario_jogo_atualizar").addEventListener("submit", atualizarJogo);
  } catch (error) {
    console.error("Erro ao buscar jogos:", error);
  }
}

/**
 * Atualiza uma tarefa específica.
 * A função é acionada pelo evento de submit do formulário de atualização.
 * @param {Event} event - O evento de submit do formulário.
 */
async function atualizarJogo(event) {
  event.preventDefault();
  const idValor = document.getElementById("jogo_id_formulario").value;
  const tituloValor = document.getElementById("jogo_titulo_formulario").value;
  const generoValor = document.getElementById("jogo_genero_formulario").value;
  const plataformaValor = document.getElementById("jogo_plataforma_formulario").value;
  const lancamentoValor = document.getElementById("jogo_lancamento_formulario").value;
  const jogo = {id: idValor, titulo: tituloValor, genero: generoValor, plataforma_principal: plataformaValor,
    data_lancamento: lancamentoValor, };

  try {
    const response = await fetch(`${API_BASE_URL}/jogos`, {
      method: "PUT",
      headers: {"Content-Type": "application/json",},
      body: JSON.stringify(jogo),
    });

    if (!response.ok) {
      throw new Error("Falha ao atualizar o jogo");
    }
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaJogos(componentePrincipal);
  } catch (error) {
    console.error("Erro ao atualizar jogo:", error);
  }
}

const jogoController = {
  renderizarJogoFormulario,
  cadastrarJogo,
  renderizarListaJogos,
  excluirJogo
};

export default jogoController;
